#include <stdarg.h>
#ifndef Printf_H
#define Printf_H
char * Printf ( char * dst , const void * end , const char * fmt , va_list arg) ;
//char *inttobin(int Zahl);
#endif
